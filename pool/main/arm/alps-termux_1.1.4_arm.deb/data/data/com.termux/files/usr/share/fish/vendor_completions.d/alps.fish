# alps fish completion
# Install: alps completion fish > ~/.config/fish/completions/alps.fish

complete -c alps -f

complete -c alps -n '__fish_use_subcommand' -a 'aliases' -d 'show active aliases'
complete -c alps -n '__fish_use_subcommand' -a 'autoclean' -d 'clean partial downloaded packages'
complete -c alps -n '__fish_use_subcommand' -a 'autoremove' -d 'remove orphaned packages'
complete -c alps -n '__fish_use_subcommand' -a 'clean' -d 'remove cached packages'
complete -c alps -n '__fish_use_subcommand' -a 'completion' -d 'generate shell completion'
complete -c alps -n '__fish_use_subcommand' -a 'config-show' -d 'show config & paths'
complete -c alps -n '__fish_use_subcommand' -a 'edit-sources' -d 'edit repository sources'
complete -c alps -n '__fish_use_subcommand' -a 'full-upgrade' -d 'sync repos and upgrade all'
complete -c alps -n '__fish_use_subcommand' -a 'help' -d 'show this help'
complete -c alps -n '__fish_use_subcommand' -a 'install' -d 'install a package'
complete -c alps -n '__fish_use_subcommand' -a 'list' -d 'list installed packages'
complete -c alps -n '__fish_use_subcommand' -a 'purge' -d 'remove a package and its data'
complete -c alps -n '__fish_use_subcommand' -a 'remove' -d 'remove a package'
complete -c alps -n '__fish_use_subcommand' -a 'repo' -d 'repo'
complete -c alps -n '__fish_use_subcommand' -a 'search' -d 'search packages'
complete -c alps -n '__fish_use_subcommand' -a 'show' -d 'show package info'
complete -c alps -n '__fish_use_subcommand' -a 'update' -d 'refresh package indexes'
complete -c alps -n '__fish_use_subcommand' -a 'upgrade' -d 'upgrade installed packages'
complete -c alps -n '__fish_use_subcommand' -a 'version' -d 'binary version'
complete -c alps -n '__fish_use_subcommand' -a 'ac' -d 'alias for autoclean'
complete -c alps -n '__fish_use_subcommand' -a 'au' -d 'alias for autoremove'
complete -c alps -n '__fish_use_subcommand' -a 'cl' -d 'alias for clean'
complete -c alps -n '__fish_use_subcommand' -a 'ed' -d 'alias for edit-sources'
complete -c alps -n '__fish_use_subcommand' -a 'fug' -d 'alias for full-upgrade'
complete -c alps -n '__fish_use_subcommand' -a 'ins' -d 'alias for install'
complete -c alps -n '__fish_use_subcommand' -a 'ls' -d 'alias for list'
complete -c alps -n '__fish_use_subcommand' -a 'pu' -d 'alias for purge'
complete -c alps -n '__fish_use_subcommand' -a 'rm' -d 'alias for remove'
complete -c alps -n '__fish_use_subcommand' -a 'se' -d 'alias for search'
complete -c alps -n '__fish_use_subcommand' -a 'sh' -d 'alias for show'
complete -c alps -n '__fish_use_subcommand' -a 'ug' -d 'alias for upgrade'
complete -c alps -n '__fish_use_subcommand' -a 'up' -d 'alias for update'

# top-level commands
# $t[1]=alps  $t[2]=cmd  $t[3]=subcmd  $t[4]=arg

# repo subcommands
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" repo; and test (count $t) -eq 2' \
    -a 'clean install list purge remove search update upgrade' -d 'repo subcommand'

# repo list sub-actions
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" repo; and contains -- "$t[3]" list ls; and test (count $t) -eq 3' \
    -a 'install remove' -d 'list action'

# repo install/search → alps-more packages
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" repo; and contains -- "$t[3]" install ins search se' \
    -a "(grep '^\[' '/var/cache/alps/more/main.txt' 2>/dev/null | tr -d '[]')" -d 'alps-more package'

# repo remove/purge/upgrade → installed alps-more packages
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" repo; and contains -- "$t[3]" remove rm purge pu upgrade ug' \
    -a "(jq -r 'keys[]' '/var/lib/alps/installed.json' 2>/dev/null)" -d 'installed alps-more package'

# aur subcommands
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" aur; and test (count $t) -eq 2' \
    -a 'build-local clean clone fetch-abs info install list orphans remove search update upgrade' -d 'aur subcommand'

# aur install/search → pacman repo + AUR
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" aur; and contains -- "$t[3]" install ins search se' \
    -a "(apt-cache pkgnames 2>/dev/null)" -d 'repo package'
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" aur; and contains -- "$t[3]" install ins search se' \
    -a "(cat '/home/runner/.cache/alps/aur-names.txt' 2>/dev/null)" -d 'AUR package'

# aur info/clone → AUR packages only
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" aur; and contains -- "$t[3]" info clone' \
    -a "(cat '/home/runner/.cache/alps/aur-names.txt' 2>/dev/null)" -d 'AUR package'

# aur remove/update/upgrade → AUR-installed packages
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" aur; and contains -- "$t[3]" remove rm update upgrade' \
    -a "(pacman -Qm 2>/dev/null | awk '{print $1}')" -d 'AUR installed package'

# aur build-local / bl → directories
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" aur; and contains -- "$t[3]" build-local bl' \
    -a "(__fish_complete_directories)" -d 'directory'

# flatpak subcommands (fp alias included)
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" flatpak fp; and test (count $t) -eq 2' \
    -a 'autoremove clean install list purge remove search show update upgrade' -d 'flatpak subcommand'

# snap subcommands (sk alias included)
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" snap sk; and test (count $t) -eq 2' \
    -a 'install list purge remove search show update upgrade' -d 'snap subcommand'

# winget subcommands (wg alias included)
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" winget wg; and test (count $t) -eq 2' \
    -a 'install list purge remove search show update upgrade' -d 'winget subcommand'

# top-level install/search → all repo packages
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" install ins search se; and test (count $t) -eq 2' \
    -a "(apt-cache pkgnames 2>/dev/null)" -d 'package'

# top-level remove/purge → installed packages
complete -c alps -n 'set -l t (commandline -poc); contains -- "$t[2]" remove rm purge pu; and test (count $t) -eq 2' \
    -a "(dpkg --get-selections 2>/dev/null | awk '{print $1}')" -d 'installed package'
